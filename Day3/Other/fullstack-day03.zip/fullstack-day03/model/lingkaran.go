package model

import "fmt"

func luas() {
	fmt.Println("luas model")
}
